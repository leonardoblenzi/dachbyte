﻿(() => {
  "use strict";

  const ROOT_ID = "davantti-insight-root";
  const STORAGE_KEYS = {
    baseUrl: "davantti_base_url",
    token: "davantti_extension_token",
    accountId: "davantti_extension_account_id",
  };

  const state = {
    open: true,
    current: null,
    cloning: false,
  };

  function text(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function firstText(selectors, root = document) {
    for (const selector of selectors) {
      const node = root.querySelector(selector);
      const value = text(node?.textContent || node?.getAttribute?.("content") || "");
      if (value) return value;
    }
    return "";
  }

  function attr(selectors, name, root = document) {
    for (const selector of selectors) {
      const node = root.querySelector(selector);
      const value = text(node?.getAttribute?.(name) || "");
      if (value) return value;
    }
    return "";
  }

  function parseMoney(raw) {
    const value = text(raw);
    if (!value) return null;
    const match = value.match(/(?:R\$\s*)?([0-9]{1,3}(?:\.[0-9]{3})*(?:,[0-9]{2})|[0-9]+(?:,[0-9]{2})?)/);
    if (!match) return null;
    const normalized = match[1].replace(/\./g, "").replace(",", ".");
    const number = Number(normalized);
    return Number.isFinite(number) ? number : null;
  }

  function formatMoney(value) {
    if (!Number.isFinite(value)) return "-";
    return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  }

  function readJsonLd() {
    const items = [];
    for (const script of document.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        const parsed = JSON.parse(script.textContent || "null");
        if (Array.isArray(parsed)) items.push(...parsed);
        else if (parsed) items.push(parsed);
      } catch (_) {}
    }
    const flat = [];
    const visit = (item) => {
      if (!item || typeof item !== "object") return;
      flat.push(item);
      if (Array.isArray(item["@graph"])) item["@graph"].forEach(visit);
    };
    items.forEach(visit);
    return flat;
  }

  function detectMarketplace() {
    const host = location.hostname.toLowerCase();
    if (host.includes("mercadolivre") || host.includes("mercadolibre")) return "ml";
    if (host.includes("shopee")) return "shopee";
    return "unknown";
  }

  function detectPageType(marketplace) {
    const path = location.pathname.toLowerCase();
    const href = location.href.toLowerCase();
    if (marketplace === "ml") {
      if (/\/mlb-?\d+|\/p\/mlb|mlb\d{6,}/i.test(href)) return "product";
      if (path.includes("/lista") || path.includes("/search") || location.search.includes("as_word")) return "search";
    }
    if (marketplace === "shopee") {
      if (/-i\.\d+\.\d+/.test(path) || path.includes("/product/")) return "product";
      if (path.includes("/search") || location.search.includes("keyword=")) return "search";
    }
    return "unknown";
  }

  function extractMetaProduct() {
    const json = readJsonLd().find((item) => {
      const type = item["@type"];
      return type === "Product" || (Array.isArray(type) && type.includes("Product"));
    }) || {};
    const offers = Array.isArray(json.offers) ? json.offers[0] : (json.offers || {});
    return {
      title: text(json.name || attr(['meta[property="og:title"]', 'meta[name="twitter:title"]'], "content")),
      price: Number(offers.price || attr(['meta[itemprop="price"]', 'meta[property="product:price:amount"]'], "content")) || null,
      image: Array.isArray(json.image) ? json.image[0] : text(json.image || attr(['meta[property="og:image"]'], "content")),
      brand: text(json.brand?.name || json.brand || ""),
      availability: text(offers.availability || ""),
    };
  }

  function extractMlProduct() {
    const meta = extractMetaProduct();
    const title = meta.title || firstText(["h1.ui-pdp-title", "h1"]);
    const seller = firstText([".ui-pdp-seller__header__title", ".ui-pdp-seller__link-trigger", ".ui-pdp-color--BLUE"]);
    const priceText = firstText([
      ".ui-pdp-price .andes-money-amount__fraction",
      ".andes-money-amount__fraction",
      '[itemprop="price"]',
    ]);
    const pictures = new Set([
      ...Array.from(document.querySelectorAll(".ui-pdp-gallery img, .ui-pdp-image, img.ui-pdp-image"))
        .map((img) => img.currentSrc || img.src)
        .filter(Boolean),
    ]);
    const shippingText = firstText([
      ".ui-pdp-media__title",
      ".ui-pdp-shipping-summary__text",
      ".ui-pdp-color--GREEN",
    ]);
    const soldText = firstText([".ui-pdp-subtitle", ".ui-pdp-header__subtitle"]);
    const attributes = Array.from(document.querySelectorAll(".ui-pdp-specs__table tr, .andes-table__row"))
      .map((row) => text(row.textContent))
      .filter(Boolean)
      .slice(0, 8);

    return {
      marketplace: "Mercado Livre",
      type: "product",
      title,
      price: meta.price || parseMoney(priceText),
      seller,
      brand: meta.brand,
      pictures: pictures.size,
      shipping: shippingText,
      sold: soldText,
      attributes,
      url: location.href,
    };
  }

  function extractShopeeProduct() {
    const meta = extractMetaProduct();
    const title = meta.title || firstText(['meta[property="og:title"]', "h1", "main h1"], document);
    const priceText = firstText([
      '[class*="price"]',
      '[data-testid*="price"]',
    ]);
    const seller = firstText([
      '[class*="shop-name"]',
      '[class*="ShopName"]',
      'a[href*="/shop/"]',
    ]);
    const pictures = new Set(Array.from(document.querySelectorAll("img"))
      .map((img) => img.currentSrc || img.src)
      .filter((src) => /shopee|cf\.shopee/i.test(src))
      .slice(0, 30));
    const shippingText = firstText([
      '[class*="shipping"]',
      '[class*="Shipping"]',
    ]);

    return {
      marketplace: "Shopee",
      type: "product",
      title,
      price: meta.price || parseMoney(priceText),
      seller,
      brand: meta.brand,
      pictures: pictures.size,
      shipping: shippingText,
      sold: firstText(['[class*="sold"]', '[class*="Sold"]']),
      attributes: [],
      url: location.href,
    };
  }

  function extractSearch(marketplace) {
    const isMl = marketplace === "ml";
    const cards = Array.from(document.querySelectorAll(isMl ? ".ui-search-result, li.ui-search-layout__item" : "[data-sqe='item'], .shopee-search-item-result__item"));
    const items = cards.slice(0, 24).map((card) => {
      const title = isMl
        ? firstText([".ui-search-item__title", "h2", "a"], card)
        : firstText(["[data-sqe='name']", "div", "a"], card);
      const price = parseMoney(firstText([".andes-money-amount__fraction", "[class*='price']"], card));
      const freeShipping = /frete gratis|frete grátis|free shipping/i.test(text(card.textContent));
      const sponsored = /patrocinado|ad|ads|sponsored/i.test(text(card.textContent));
      return { title, price, freeShipping, sponsored };
    }).filter((item) => item.title || item.price);

    const prices = items.map((item) => item.price).filter(Number.isFinite);
    const avg = prices.length ? prices.reduce((sum, value) => sum + value, 0) / prices.length : null;
    const min = prices.length ? Math.min(...prices) : null;
    const max = prices.length ? Math.max(...prices) : null;
    const freeShippingCount = items.filter((item) => item.freeShipping).length;
    const sponsoredCount = items.filter((item) => item.sponsored).length;

    return {
      marketplace: isMl ? "Mercado Livre" : "Shopee",
      type: "search",
      title: document.title,
      count: items.length,
      avg,
      min,
      max,
      freeShippingCount,
      sponsoredCount,
      items,
      url: location.href,
    };
  }

  function scoreProduct(data) {
    let score = 45;
    const warnings = [];
    const wins = [];
    const titleLength = text(data.title).length;

    if (titleLength >= 45 && titleLength <= 90) { score += 14; wins.push("Titulo em bom tamanho."); }
    else if (titleLength) { score += 5; warnings.push("Titulo pode ser melhorado em tamanho e clareza."); }
    else warnings.push("Nao consegui ler o titulo do anuncio.");

    if (Number.isFinite(data.price)) { score += 10; wins.push("Preco identificado."); }
    else warnings.push("Preco nao identificado com seguranca.");

    if ((data.pictures || 0) >= 5) { score += 12; wins.push("Boa quantidade de imagens."); }
    else warnings.push("Poucas imagens detectadas. Avalie reforcar fotos.");

    if (data.shipping) { score += 8; wins.push("Informacao de frete visivel."); }
    else warnings.push("Frete nao identificado no primeiro carregamento.");

    if (data.seller) score += 6;
    else warnings.push("Vendedor nao identificado no DOM atual.");

    if ((data.attributes || []).length >= 3) score += 5;
    else warnings.push("Poucos atributos tecnicos detectados.");

    return { score: Math.max(0, Math.min(100, score)), warnings: warnings.slice(0, 4), wins: wins.slice(0, 3) };
  }

  function scoreSearch(data) {
    const warnings = [];
    const wins = [];
    if (data.count >= 12) wins.push(`${data.count} anuncios lidos na pagina.`);
    else warnings.push("Poucos anuncios detectados. Role a pagina se necessario.");
    if (data.freeShippingCount) wins.push(`${data.freeShippingCount} anuncios com frete gratis/sinal equivalente.`);
    if (data.sponsoredCount) warnings.push(`${data.sponsoredCount} anuncios parecem patrocinados.`);
    if (Number.isFinite(data.avg)) wins.push(`Preco medio visivel: ${formatMoney(data.avg)}.`);
    return { score: Math.min(100, 50 + data.count * 2 + data.freeShippingCount), warnings, wins };
  }

  function analyzePage() {
    const marketplace = detectMarketplace();
    const pageType = detectPageType(marketplace);
    if (marketplace === "unknown" || pageType === "unknown") return null;
    const data = pageType === "search"
      ? extractSearch(marketplace)
      : marketplace === "ml" ? extractMlProduct() : extractShopeeProduct();
    const analysis = pageType === "search" ? scoreSearch(data) : scoreProduct(data);
    return { ...data, ...analysis, marketplaceKey: marketplace };
  }

  function metric(label, value) {
    return `<div class="dvti-metric"><span>${label}</span><strong>${value || "-"}</strong></div>`;
  }

  function list(items, className = "") {
    if (!items?.length) return "";
    return `<ul class="dvti-list ${className}">${items.map((item) => `<li>${item}</li>`).join("")}</ul>`;
  }

  function renderPanel(data) {
    const root = ensureRoot();
    const body = root.querySelector(".dvti-panel-body");
    const title = text(data.title) || "Pagina detectada";
    const isProduct = data.type === "product";
    const cloneButton = data.marketplaceKey === "ml" && isProduct
      ? `<button class="dvti-action dvti-primary" data-action="clone">Clonar para minha conta</button>`
      : `<button class="dvti-action" data-action="open-app">Abrir Davantti</button>`;

    body.innerHTML = `
      <div class="dvti-chip-row">
        <span class="dvti-chip">${data.marketplace}</span>
        <span class="dvti-chip muted">${isProduct ? "Anuncio" : "Busca"}</span>
      </div>
      <h3>${title}</h3>
      <div class="dvti-score"><span>Score Davantti</span><strong>${data.score}</strong></div>
      <div class="dvti-grid">
        ${isProduct ? metric("Preco", formatMoney(data.price)) : metric("Media", formatMoney(data.avg))}
        ${isProduct ? metric("Fotos", data.pictures || "-") : metric("Lidos", data.count || "-")}
        ${isProduct ? metric("Vendedor", data.seller || "-") : metric("Frete gratis", data.freeShippingCount || "0")}
        ${isProduct ? metric("Frete", data.shipping ? "Visivel" : "Nao lido") : metric("Patrocinados", data.sponsoredCount || "0")}
      </div>
      ${list(data.wins, "ok")}
      ${list(data.warnings, "warn")}
      <div class="dvti-actions">
        <button class="dvti-action" data-action="refresh">Atualizar leitura</button>
        ${cloneButton}
      </div>
      <p class="dvti-foot">Analise local da pagina atual. Dados estimados dependem do HTML carregado.</p>
    `;
  }

  function ensureRoot() {
    let root = document.getElementById(ROOT_ID);
    if (root) return root;
    root = document.createElement("div");
    root.id = ROOT_ID;
    root.innerHTML = `
      <button class="dvti-fab" type="button" aria-label="Abrir Davantti">D</button>
      <aside class="dvti-panel">
        <header><strong>Davantti</strong><button type="button" class="dvti-close" aria-label="Fechar">x</button></header>
        <div class="dvti-panel-body"></div>
      </aside>
    `;
    document.documentElement.appendChild(root);
    root.querySelector(".dvti-fab").addEventListener("click", () => setOpen(true));
    root.querySelector(".dvti-close").addEventListener("click", () => setOpen(false));
    root.addEventListener("click", handleActionClick);
    setOpen(state.open);
    return root;
  }

  function setOpen(open) {
    state.open = open;
    const root = ensureRoot();
    root.classList.toggle("is-open", open);
  }

  function getStorage(keys) {
    return chrome.storage.local.get(keys);
  }

  function normalizeBaseUrl(value) {
    return String(value || "https://www.davanttisuite.com.br/ml").replace(/\/+$/, "");
  }

  async function cloneFromPage(button) {
    if (state.cloning) return;
    state.cloning = true;
    const original = button.textContent;
    button.textContent = "Enviando...";
    button.disabled = true;
    try {
      const saved = await getStorage(Object.values(STORAGE_KEYS));
      const token = saved[STORAGE_KEYS.token] || "";
      const accountId = saved[STORAGE_KEYS.accountId] || "";
      const baseUrl = normalizeBaseUrl(saved[STORAGE_KEYS.baseUrl]);
      if (!token) throw new Error("Faça login na extensão primeiro.");
      if (!accountId) throw new Error("Selecione uma conta ML no popup da extensão.");

      const response = await fetch(`${baseUrl}/api/extension/clonar-anuncio/browser-capture`, {
        method: "POST",
        headers: {
          accept: "application/json",
          "content-type": "application/json",
          authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          account_id: accountId,
          url: location.href,
          title: document.title || "",
          html: document.documentElement ? document.documentElement.outerHTML : "",
          captured_at: new Date().toISOString(),
        }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || payload?.ok === false) throw new Error(payload?.error || `Erro HTTP ${response.status}`);
      button.textContent = payload?.draft?.id ? `Rascunho #${payload.draft.id}` : "Rascunho criado";
    } catch (error) {
      button.textContent = error.message || "Falha ao clonar";
      setTimeout(() => { button.textContent = original; button.disabled = false; }, 2600);
      return;
    } finally {
      state.cloning = false;
    }
  }

  async function openApp() {
    const saved = await getStorage([STORAGE_KEYS.baseUrl]);
    window.open(`${normalizeBaseUrl(saved[STORAGE_KEYS.baseUrl])}/painel`, "_blank", "noopener,noreferrer");
  }

  function handleActionClick(event) {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const action = button.dataset.action;
    if (action === "refresh") runAnalysis();
    if (action === "clone") cloneFromPage(button);
    if (action === "open-app") openApp();
  }

  function runAnalysis() {
    const data = analyzePage();
    if (!data) return;
    state.current = data;
    renderPanel(data);
  }

  const observer = new MutationObserver(() => {
    clearTimeout(observer._timer);
    observer._timer = setTimeout(runAnalysis, 700);
  });

  function boot() {
    runAnalysis();
    observer.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(runAnalysis, 1800);
    setTimeout(runAnalysis, 4200);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
